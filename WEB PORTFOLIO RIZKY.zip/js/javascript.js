$(document).ready(function(){
    $('.customer-logos').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 4
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 3
            }
        }]
    });
});



$('img').bind('contextmenu', function(e){
    return false;
});


$(function () {
        
    var filterList = {
    
        init: function () {
        
            // MixItUp plugin
            // http://mixitup.io
            $('#portfoliolist').mixItUp({
                selectors: {
              target: '.portfolio',
              filter: '.filter' 
          },
          load: {
              filter: '.app, .cards, .icon, .logo, .web' // show app tab on first load
            }     
            });                             
        
        }

    };
    
    // Run the show!
    filterList.init();
    
});     



   var prevScrollpos = window.pageYOffset;
            window.onscroll = function() {
            var currentScrollPos = window.pageYOffset;
              if (prevScrollpos > currentScrollPos) {
                document.getElementById("navbar").style.top = "0";
              } else {
                document.getElementById("navbar").style.top = "-500px";
              }
              prevScrollpos = currentScrollPos;
            }


